/* ======================================================
   APP ORKESTRATOR – FASE 4.2
====================================================== */
import "./js/canvas.js";
import "./js/state.js";
import "./js/sides.js";
import "./js/accordion.js";
import "./js/upload.js";
import "./js/objects.js";
import "./js/text.js";
import "./js/ui-sync.js";
import "./js/init.js";
try{ window.__BOOT_OK__ && window.__BOOT_OK__(); }catch(e){}
